import torch
import torch.nn as nn
from torch.nn import init
import torch.nn.functional as F
from torch.optim import lr_scheduler
import numpy as np
from torchvision.transforms import ToTensor
import functools
from einops import rearrange
import cv2
import models
import math
import kornia
import os
from kornia.filters.kernels import get_gaussian_kernel2d
from PIL import Image
from models.help_funcs import Transformer, TransformerDecoder, TwoLayerConv2d
from models.ChangeFormer import ChangeFormerV1, ChangeFormerV2, ChangeFormerV3, ChangeFormerV4, ChangeFormerV5, ChangeFormerV6
from models.SiamUnet_diff import SiamUnet_diff
from models.SiamUnet_conc import SiamUnet_conc
from models.Unet import Unet
from models.DTCDSCN import CDNet34
from typing import List, Dict
from sklearn.decomposition import PCA
from scipy import signal
import torchvision.models as models2
import matplotlib.pyplot as plt
plt.ioff()  # 
torch.cuda.empty_cache()
import warnings
import os
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True,max_split_size_mb:128"
# 
warnings.filterwarnings("ignore", message="grid: in an upcoming release") 

# 
warnings.filterwarnings("ignore", message="Backend tkagg is interactive backend")
device = "cuda" if torch.cuda.is_available() else "cpu"   

###############################################################################
# Helper Functions
###############################################################################

def get_scheduler(optimizer, args):

    if args.lr_policy == 'linear':
        def lambda_rule(epoch):
            lr_l = 1- epoch/ float(args.max_epochs + 1)
            return lr_l
        scheduler = lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda_rule)
    elif args.lr_policy == 'step':
        step_size = args.max_epochs//3
        # 
        scheduler = lr_scheduler.StepLR(optimizer, step_size=step_size, gamma=0.1)
    elif args.lr_policy == 'cosine':
        # 
        scheduler = lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.max_epochs, eta_min=1e-6)
    else:
        return NotImplementedError('learning rate policy [%s] is not implemented', args.lr_policy)
    return scheduler


class Identity(nn.Module):
    def forward(self, x):
        return x


def get_norm_layer(norm_type='instance'):

    if norm_type == 'batch':
        norm_layer = functools.partial(nn.BatchNorm2d, affine=True, track_running_stats=True)
    elif norm_type == 'instance':
        norm_layer = functools.partial(nn.InstanceNorm2d, affine=False, track_running_stats=False)
    elif norm_type == 'none':
        norm_layer = lambda x: Identity()
    else:
        raise NotImplementedError('normalization layer [%s] is not found' % norm_type)
    return norm_layer


def init_weights(net, init_type='normal', init_gain=0.02):

    def init_func(m):  # define the initialization function
        classname = m.__class__.__name__
        if hasattr(m, 'weight') and (classname.find('Conv') != -1 or classname.find('Linear') != -1):
            if init_type == 'normal':
                init.normal_(m.weight.data, 0.0, init_gain)
            elif init_type == 'xavier':
                init.xavier_normal_(m.weight.data, gain=init_gain)
            elif init_type == 'kaiming':
                init.kaiming_normal_(m.weight.data, a=0, mode='fan_in')
            elif init_type == 'orthogonal':
                init.orthogonal_(m.weight.data, gain=init_gain)
            else:
                raise NotImplementedError('initialization method [%s] is not implemented' % init_type)
            if hasattr(m, 'bias') and m.bias is not None:
                init.constant_(m.bias.data, 0.0)
        elif classname.find('BatchNorm2d') != -1:  # BatchNorm Layer's weight is not a matrix; only normal distribution applies.
            init.normal_(m.weight.data, 1.0, init_gain)
            init.constant_(m.bias.data, 0.0)

    # print('initialize network with %s' % init_type)
    net.apply(init_func)  # apply the initialization function <init_func>


def init_net(net, init_type='normal', init_gain=0.02, gpu_ids=[]):

    if len(gpu_ids) > 0:
        assert(torch.cuda.is_available())
        net.to(gpu_ids[0])
        if len(gpu_ids) > 1:
            net = torch.nn.DataParallel(net, gpu_ids)  # multi-GPUs
    init_weights(net, init_type, init_gain=init_gain)
    return net

def define_G(args, init_type='normal', init_gain=0.02, gpu_ids=[]):
    if args.net_G == 'base_resnet18':
        net = FGCD_R(input_nc=3, output_nc=2, output_sigmoid=False)

    elif args.net_G == 'base_transformer_pos_s4':
        net = FGCD_R(input_nc=3, output_nc=2, token_len=4, resnet_stages_num=4,
                             with_pos='learned')

    elif args.net_G == 'base_transformer_pos_s4_dd8':
        net = FGCD_R(input_nc=3, output_nc=2, token_len=4, resnet_stages_num=4,
                             with_pos='learned', enc_depth=1, dec_depth=8)

    elif args.net_G == 'base_transformer_pos_s4_dd8_dedim8':
        net = FGCD_R(input_nc=3, output_nc=2, token_len=4, resnet_stages_num=4,
                             with_pos='learned', enc_depth=1, dec_depth=8, decoder_dim_head=8)
        

    elif args.net_G == 'ChangeFormerV1':
        net = ChangeFormerV1() #ChangeFormer with Transformer Encoder and Convolutional Decoder
    
    elif args.net_G == 'ChangeFormerV2':
        net = ChangeFormerV2() #ChangeFormer with Transformer Encoder and Convolutional Decoder

    elif args.net_G == 'ChangeFormerV3':
        net = ChangeFormerV3() #ChangeFormer with Transformer Encoder and Convolutional Decoder (Fuse)

    elif args.net_G == 'ChangeFormerV4':
        net = ChangeFormerV4() #ChangeFormer with Transformer Encoder and Convolutional Decoder (Fuse)
    
    elif args.net_G == 'ChangeFormerV5':
        net = ChangeFormerV5(embed_dim=args.embed_dim) #ChangeFormer with Transformer Encoder and Convolutional Decoder (Fuse)

    elif args.net_G == 'ChangeFormerV6':
        net = ChangeFormerV6(embed_dim=args.embed_dim) #ChangeFormer with Transformer Encoder and Convolutional Decoder (Fuse)
    
    elif args.net_G == "SiamUnet_diff":

        net = SiamUnet_diff(input_nbr=3, label_nbr=2)

    elif args.net_G == "SiamUnet_conc":

        net = SiamUnet_conc(input_nbr=3, label_nbr=2)

    elif args.net_G == "Unet":
        #Usually abbreviated as FC-EF = Image Level Concatenation
        #Implementation of ``Fully convolutional siamese networks for change detection''
        #Code copied from: https://github.com/rcdaudt/fully_convolutional_change_detection
        net = Unet(input_nbr=3, label_nbr=2)
    
    elif args.net_G == "DTCDSCN":
        #The implementation of the paper"Building Change Detection for Remote Sensing Images Using a Dual Task Constrained Deep Siamese Convolutional Network Model "
        #Code copied from: https://github.com/fitzpchao/DTCDSCN
        net = CDNet34(in_channels=3)

    else:
        raise NotImplementedError('Generator model name [%s] is not recognized' % args.net_G)
   
    return init_net(net, init_type, init_gain, gpu_ids)



class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout, max_len=5000):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2) * -(math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        device = x.device
        x = x + self.pe[:, :x.size(1)].to(device)
        return self.dropout(x)


class AffineTransform(nn.Module):
    def __init__(self, degrees=0, translate=0.1, return_warp=False):
        super(AffineTransform, self).__init__()
        self.trs = kornia.augmentation.RandomAffine(degrees, (translate, translate), return_transform=True, p=1)
        self.return_warp = return_warp

    def forward(self, input):
        device = input.device
        batch_size, _, height, weight = input.shape
        warped, affine_param = self.trs(input)

        T = torch.FloatTensor([[2. / weight, 0, -1],
                               [0, 2. / height, -1],
                               [0, 0, 1]]).repeat(batch_size, 1, 1).to(device)
        theta = torch.inverse(torch.bmm(torch.bmm(T, affine_param), torch.inverse(T)))

        base = kornia.utils.create_meshgrid(height, weight, device=device).to(input.dtype)
        grid = F.affine_grid(theta[:, :2, :], size=input.size(), align_corners=False)

        disp = grid - base

        if self.return_warp:
            warped_grid_sample = F.grid_sample(input, grid)
            return warped_grid_sample, disp
        else:
            return disp


class ElasticTransform(nn.Module):
    def __init__(self, kernel_size=63, sigma=32, align_corners=False, mode="bilinear", return_warp=False):
        super(ElasticTransform, self).__init__()
        self.kernel_size = kernel_size
        self.sigma = sigma
        self.align_corners = align_corners
        self.mode = mode
        self.return_warp = return_warp

    def forward(self, input):
        batch_size, _, height, weight = input.shape
        device = input.device
        noise = torch.rand(batch_size, 2, height, weight, device=device) * 2 - 1
        
        if self.return_warp:
            warped, disp = self.elastic_transform2d(input, noise)
            return warped, disp
        else:
            disp = self.elastic_transform2d(input, noise)
            return disp

    def elastic_transform2d(self, image: torch.Tensor, noise: torch.Tensor):
        if not isinstance(image, torch.Tensor):
            raise TypeError(f"Input image is not torch.Tensor. Got {type(image)}")

        if not isinstance(noise, torch.Tensor):
            raise TypeError(f"Input noise is not torch.Tensor. Got {type(noise)}")

        if not len(image.shape) == 4:
            raise ValueError(f"Invalid image shape, we expect BxCxHxW. Got: {image.shape}")

        if not len(noise.shape) == 4 or noise.shape[1] != 2:
            raise ValueError(f"Invalid noise shape, we expect Bx2xHxW. Got: {noise.shape}")

        device = image.device
        kernel_x = get_gaussian_kernel2d((self.kernel_size, self.kernel_size), (self.sigma, self.sigma))[None]
        kernel_y = get_gaussian_kernel2d((self.kernel_size, self.kernel_size), (self.sigma, self.sigma))[None]

        disp_x = noise[:, :1].to(device)
        disp_y = noise[:, 1:].to(device)

        disp_x = kornia.filters.filter2d(disp_x, kernel=kernel_y, border_type="constant")
        disp_y = kornia.filters.filter2d(disp_y, kernel=kernel_x, border_type="constant")

        disp = torch.cat([disp_x, disp_y], dim=1).permute(0, 2, 3, 1)

        if self.return_warp:
            b, c, h, w = image.shape
            base = kornia.utils.create_meshgrid(h, w, device=image.device).to(image.dtype)
            grid = (base + disp).clamp(-1, 1)
            warped = F.grid_sample(image, grid, align_corners=self.align_corners, mode=self.mode)
            return warped, disp
        else:
            return disp


class ImageTransform(nn.Module):
    def __init__(self, ET_kernel_size=101, ET_kernel_sigma=16, AT_translate=0.01, convert_to_gray=True):
        super(ImageTransform, self).__init__()
        self.affine = AffineTransform(translate=AT_translate)
        self.elastic = ElasticTransform(kernel_size=ET_kernel_size, sigma=ET_kernel_sigma)
        self.convert_to_gray = convert_to_gray

    def _convert_to_grayscale(self, x):
        if x.size(1) == 3:
            return  ~ * x[:,0:1,:,:] + ~  * x[:,1:2,:,:] + ~ * x[:,2:3,:,:]#choose,
        return x

    def generate_grid(self, input):
        device = input.device
        batch_size, _, height, weight = input.size()
        affine_disp = self.affine(input)
        elastic_disp = self.elastic(input)
        base = kornia.utils.create_meshgrid(height, weight).to(dtype=input.dtype).repeat(batch_size, 1, 1, 1).to(device)
        disp = affine_disp + elastic_disp
        grid = base + disp
        return grid

    def make_transform_matrix(self, grid):
        device = grid.device
        batch_size, height, weight, _ = grid.size()
        grid_s = torch.zeros_like(grid)
        grid_s[:, :, :, 0] = ((grid[:, :, :, 0] / 2) + 0.5) * (weight - 1)
        grid_s[:, :, :, 1] = ((grid[:, :, :, 1] / 2) + 0.5) * (height - 1)
        grid_s = torch.round(grid_s).to(dtype=torch.int64)
        base_s = kornia.utils.create_meshgrid(height, weight, normalized_coordinates=False).to(dtype=grid.dtype).repeat(
            batch_size, 1, 1, 1).to(device)
        x_index = base_s.reshape([batch_size, height * weight, 2]).to(dtype=torch.int64)
        y_index = grid_s.reshape([batch_size, height * weight, 2]).to(dtype=torch.int64)
        x_index_o = x_index[:, :, 0] + x_index[:, :, 1] * height
        y_index_o = y_index[:, :, 0] + y_index[:, :, 1] * height

        mask_x_min = (y_index[:, :, 0] > -1).to(torch.int64).unsqueeze(dim=-1).repeat(1, 1, 2)
        mask_y_min = (y_index[:, :, 1] > -1).to(torch.int64).unsqueeze(dim=-1).repeat(1, 1, 2)
        mask_x_max = (y_index[:, :, 0] < weight).to(torch.int64).unsqueeze(dim=-1).repeat(1, 1, 2)
        mask_y_max = (y_index[:, :, 1] < height).to(torch.int64).unsqueeze(dim=-1).repeat(1, 1, 2)
        mask = torch.mul(torch.mul(mask_x_min, mask_y_min), torch.mul(mask_x_max, mask_y_max))
        x_index_o = torch.mul(x_index_o, mask[:, :, 0])
        y_index_o = torch.mul(y_index_o, mask[:, :, 0])
        filler = mask[:, :, 0].to(dtype=torch.float32)

        index = torch.cat([x_index_o.unsqueeze(dim=1), y_index_o.unsqueeze(dim=1)], dim=1)
        index_r = torch.cat([y_index_o.unsqueeze(dim=1), x_index_o.unsqueeze(dim=1)], dim=1)

        return index, index_r, filler

    def forward(self, image_1, image_2):
        assert (image_1.size()[2:] == image_2.size()[2:])
        
        if self.convert_to_gray:
            image_1_gray = self._convert_to_grayscale(image_1)
            image_2_gray = self._convert_to_grayscale(image_2)
        else:
            image_1_gray = image_1
            image_2_gray = image_2
        
        grid = self.generate_grid(image_1_gray)
        index, index_r, filler = self.make_transform_matrix(grid)
        image_1_warp = F.grid_sample(image_1, grid, align_corners=False, mode='bilinear')
        image_2_warp = F.grid_sample(image_2, grid, align_corners=False, mode='bilinear')
        return image_1_warp, image_2_warp, index, index_r, filler

###############################################################################
# Basic Network Modules
###############################################################################

class FeatureExtractor(nn.Module):
    """
    Feature extraction module with enhanced adaptation for remote sensing images
    """
    def __init__(self, input_nc=3, backbone='resnet18'):
        super(FeatureExtractor, self).__init__()
        self.backbone = backbone
        
        # Basic feature extraction layers
        self.conv1 = nn.Conv2d(input_nc, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        
        # ResNet-like blocks
        self.layer1 = self._make_layer(64, 64, 2)
        self.layer2 = self._make_layer(64, 128, 2, stride=2)
        
        # Additional processing with local response normalization
        self.lrn = nn.LocalResponseNorm(size=5, alpha=0.0001, beta=0.75, k=1.0)
        
        # Directional gradient activation function
        self.dga = DirectionalGradientActivation()
        
        # Adaptive instance normalization
        self.ain = AdaptiveInstanceNorm2d(128)
        
        # Final conv to get desired channel number
        self.final_conv = nn.Conv2d(128, 32, kernel_size=3, padding=1)
        

        self.channel_attention = ChannelAttention(32)
        self.spatial_attention = SpatialAttention()
    
    def _make_layer(self, in_channels, out_channels, blocks, stride=1):
        layers = []
        layers.append(BasicBlock(in_channels, out_channels, stride))
        for _ in range(1, blocks):
            layers.append(BasicBlock(out_channels, out_channels))
        return nn.Sequential(*layers)
    
    def forward(self, x):
        # Base feature extraction
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)
        
        # ResNet-like processing
        x = self.layer1(x)
        x = self.layer2(x)
        
        # Enhanced processing
        x = self.lrn(x)
        x = self.dga(x)
        x = self.ain(x)
        x = self.final_conv(x)
        
        x = self.channel_attention(x) * x
        x = self.spatial_attention(x) * x
        
        return x


class ChannelAttention(nn.Module):
    def __init__(self, in_channels, reduction_ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        
        self.fc = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // reduction_ratio, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels // reduction_ratio, in_channels, 1, bias=False)
        )
        self.sigmoid = nn.Sigmoid()
    
    def forward(self, x):
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        out = avg_out + max_out
        return self.sigmoid(out)


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=kernel_size//2, bias=False)
        self.sigmoid = nn.Sigmoid()
    
    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv(x)
        return self.sigmoid(x)


class BasicBlock(nn.Module):
    """Basic residual block similar to ResNet"""
    def __init__(self, in_channels, out_channels, stride=1):
        super(BasicBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels)
        
        # Shortcut connection
        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels)
            )
    
    def forward(self, x):
        residual = x
        
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        
        out = self.conv2(out)
        out = self.bn2(out)
        
        out += self.shortcut(residual)
        out = self.relu(out)
        
        return out


class DirectionalGradientActivation(nn.Module):

    def __init__(self, directions=8):
        super(DirectionalGradientActivation, self).__init__()
        self.directions = directions
        
        # Create directional gradient kernels
        kernels = []
        for i in range(self.directions):
            angle = i * np.pi / self.directions
            dx = np.cos(angle)
            dy = np.sin(angle)
            
            kernel = torch.zeros(1, 1, 3, 3)
            kernel[0, 0, 1, 1] = 0
            kernel[0, 0, 1 + int(np.round(dy)), 1 + int(np.round(dx))] = 1
            kernel[0, 0, 1 - int(np.round(dy)), 1 - int(np.round(dx))] = -1
            
            kernels.append(kernel)
        
        self.register_buffer('kernels', torch.cat(kernels, dim=0))
    
    def forward(self, x):
        b, c, h, w = x.shape
        output = torch.zeros_like(x).to(x.device)
        
        for i in range(c):
            channel = x[:, i:i+1, :, :]
            max_response = torch.zeros_like(channel).to(x.device)
            
            for j in range(self.directions):
                kernel = self.kernels[j:j+1].to(x.device)
                response = F.conv2d(channel, kernel, padding=1)
                max_response = torch.max(max_response, torch.abs(response))
            
            output[:, i:i+1, :, :] = max_response
        
        return output + x  # Residual connection


class AdaptiveInstanceNorm2d(nn.Module):

    def __init__(self, num_features):
        super(AdaptiveInstanceNorm2d, self).__init__()
        self.num_features = num_features
        self.instance_norm = nn.InstanceNorm2d(num_features, affine=False)
        self.adaptive_params = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(num_features, num_features, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(num_features, num_features*2, kernel_size=1)
        )
    
    def forward(self, x):
        # Instance normalization
        normalized = self.instance_norm(x)
        
        # Generate adaptive parameters
        params = self.adaptive_params(x)
        gamma, beta = params.chunk(2, dim=1)
        
        # Apply adaptive parameters
        return normalized * (1 + gamma) + beta


###############################################################################
# FGCD-R Core Modules
###############################################################################

class SACAM(nn.Module):
  
    def __init__(self, in_channels=32):
        super(SACAM, self).__init__()
        self.in_channels = in_channels
        
        #
        self.attention_gen = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels, in_channels, kernel_size=1),
            nn.Sigmoid()
        )
        
        # 
        self.process = nn.Sequential(
            nn.Conv2d(in_channels, in_channels*2, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_channels*2),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels*2, in_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_channels)
        )
        
        # 
        self.mhsa = MultiHeadSelfAttention(in_channels, heads=8)
        
        #
        self.alpha = nn.Parameter(torch.ones(1))
       
        self.gamma = nn.Parameter(torch.ones(1))
        
    def forward(self, f1, f2):

        a1 = self.attention_gen(f1)
        a2 = self.attention_gen(f2)
        
  
        f1_enhanced = self.process(f1 * a1)
        f2_enhanced = self.process(f2 * a2)
        
   
        f1_attn = self.mhsa(f1_enhanced)
        f2_attn = self.mhsa(f2_enhanced)
        

        f1_out = f1 + self.gamma * (self.alpha * f1_attn)
        f2_out = f2 + self.gamma * (self.alpha * f2_attn)
        
        return f1_out, f2_out


class MultiHeadSelfAttention(nn.Module):

    def __init__(self, dim, heads=8):
        super(MultiHeadSelfAttention, self).__init__()
        self.dim = dim
        self.heads = heads
        self.head_dim = dim // heads
        
        self.to_q = nn.Conv2d(dim, dim, kernel_size=1)
        self.to_k = nn.Conv2d(dim, dim, kernel_size=1)
        self.to_v = nn.Conv2d(dim, dim, kernel_size=1)
        
        # 
        self.norm_q = nn.BatchNorm2d(dim)
        self.norm_k = nn.BatchNorm2d(dim)
        self.norm_v = nn.BatchNorm2d(dim)
        
        self.proj = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=1),
            nn.BatchNorm2d(dim)
        )

        self.dropout = nn.Dropout(0.1)
        
    def forward(self, x):
        b, c, h, w = x.shape
        n = h * w

        q = self.norm_q(self.to_q(x)).view(b, self.heads, self.head_dim, n)
        k = self.norm_k(self.to_k(x)).view(b, self.heads, self.head_dim, n)
        v = self.norm_v(self.to_v(x)).view(b, self.heads, self.head_dim, n)

        q = q.transpose(2, 3)  # [b, heads, n, head_dim]
        v = v.transpose(2, 3)  # [b, heads, n, head_dim]

        attn = torch.matmul(q, k) / np.sqrt(self.head_dim)  # [b, heads, n, n]
        attn = F.softmax(attn, dim=-1)
        attn = self.dropout(attn)

        out = torch.matmul(attn, v)  # [b, heads, n, head_dim]
        out = out.transpose(2, 3).contiguous().view(b, c, h, w)
        
        out = self.proj(out)
        
        return out


class DTMM(nn.Module):

    def __init__(self, in_channels=32):
        super(DTMM, self).__init__()
        self.in_channels = in_channels
        
      
        self.dfn_full = DeformationFieldNetwork(in_channels)
        self.dfn_half = DeformationFieldNetwork(in_channels)
        self.dfn_quarter = DeformationFieldNetwork(in_channels)
        

        self.temporal_memory = TemporalMemoryUnit(in_channels)

        self.downsample_half = nn.AvgPool2d(kernel_size=2, stride=2)
        self.downsample_quarter = nn.AvgPool2d(kernel_size=4, stride=4)
        self.upsample_half = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.upsample_quarter = nn.Upsample(scale_factor=4, mode='bilinear', align_corners=True)

        self.combine_flows = nn.Sequential(
            nn.Conv2d(in_channels=6, out_channels=16, kernel_size=3, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels=16, out_channels=2, kernel_size=3, padding=1)
        )
        

        self.flow_attention = nn.Sequential(
            nn.Conv2d(in_channels=6, out_channels=1, kernel_size=1),
            nn.Sigmoid()
        )
        
    def forward(self, f1, f2):
    
        flow_a2b_full = self.dfn_full(f1, f2)
        flow_b2a_full = self.dfn_full(f2, f1)
        
     
        f1_half = self.downsample_half(f1)
        f2_half = self.downsample_half(f2)
        flow_a2b_half = self.dfn_half(f1_half, f2_half)
        flow_b2a_half = self.dfn_half(f2_half, f1_half)
        flow_a2b_half = self.upsample_half(flow_a2b_half) * 2  # 
        flow_b2a_half = self.upsample_half(flow_b2a_half) * 2
        

        f1_quarter = self.downsample_quarter(f1)
        f2_quarter = self.downsample_quarter(f2)
        flow_a2b_quarter = self.dfn_quarter(f1_quarter, f2_quarter)
        flow_b2a_quarter = self.dfn_quarter(f2_quarter, f1_quarter)
        flow_a2b_quarter = self.upsample_quarter(flow_a2b_quarter) * 4  
        flow_b2a_quarter = self.upsample_quarter(flow_b2a_quarter) * 4
        
      
        flow_a2b_combined = torch.cat([flow_a2b_full, flow_a2b_half, flow_a2b_quarter], dim=1)
        flow_b2a_combined = torch.cat([flow_b2a_full, flow_b2a_half, flow_b2a_quarter], dim=1)
        
   
        flow_a2b_attn = self.flow_attention(flow_a2b_combined)
        flow_b2a_attn = self.flow_attention(flow_b2a_combined)
        
        flow_a2b = self.combine_flows(flow_a2b_combined * flow_a2b_attn)
        flow_b2a = self.combine_flows(flow_b2a_combined * flow_b2a_attn)
        
     
        f1_warped = self._spatial_transform(f1, flow_a2b)
        f2_warped = self._spatial_transform(f2, flow_b2a)

        m1 = self.temporal_memory(f1, f2_warped)
        m2 = self.temporal_memory(f2, f1_warped)
        

        diff = torch.abs(m1 - m2)
        
        return m1, m2, diff
    
    def _spatial_transform(self, x, flow):
       
        b, _, h, w = x.shape
        
     
        grid_y, grid_x = torch.meshgrid(
            torch.linspace(-1, 1, h, device=x.device),
            torch.linspace(-1, 1, w, device=x.device),
            indexing='ij'  
        )
        grid = torch.stack((grid_x, grid_y), dim=2).unsqueeze(0)
 
        if b > 1:
            grid = grid.repeat(b, 1, 1, 1)
        
       
        flow_scaled = flow.clone() * 5.6#choose
        flow_scaled[:, 0] = flow_scaled[:, 0] / ((w - 1) / 2)
        flow_scaled[:, 1] = flow_scaled[:, 1] / ((h - 1) / 2)
        
        
        sampling_grid = grid + flow_scaled.permute(0, 2, 3, 1)
  
        x_warped = F.grid_sample(x, sampling_grid, mode='bilinear', padding_mode='border', align_corners=True)
        
        return x_warped


class DeformationFieldNetwork(nn.Module):

    def __init__(self, in_channels):
        super(DeformationFieldNetwork, self).__init__()
        
        self.conv1 = nn.Conv2d(in_channels*2, 64, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm2d(64)
        self.conv2 = nn.Conv2d(64, 64, kernel_size=3, padding=1)
        self.bn2 = nn.BatchNorm2d(64)
        self.conv3 = nn.Conv2d(64, 32, kernel_size=3, padding=1)
        self.bn3 = nn.BatchNorm2d(32)
        
     
        self.flow = nn.Sequential(
            nn.Conv2d(32, 16, kernel_size=3, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True),
            nn.Conv2d(16, 2, kernel_size=3, padding=1),
            nn.Tanh()  
        )
        
        self.relu = nn.ReLU(inplace=True)
        
    def forward(self, f1, f2):
     
        x = torch.cat([f1, f2], dim=1)
        
        x = self.relu(self.bn1(self.conv1(x)))
        x = self.relu(self.bn2(self.conv2(x)))
        x = self.relu(self.bn3(self.conv3(x)))
        
        flow = self.flow(x) * 32.0  # choose
        
        return flow


class TemporalMemoryUnit(nn.Module):
  
    def __init__(self, in_channels):
        super(TemporalMemoryUnit, self).__init__()
        self.in_channels = in_channels
        
        # 
        self.cell = nn.Sequential(
            nn.Conv2d(in_channels*2, in_channels*2, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_channels*2),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels*2, in_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_channels),
            nn.Sigmoid()
        )
        
        # 
        self.update_gate = nn.Sequential(
            nn.Conv2d(in_channels*2, in_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_channels),
            nn.Sigmoid()
        )

        self.output_transform = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=1),
            nn.BatchNorm2d(in_channels)
        )

        self.change_gate = nn.Sequential(
            nn.Conv2d(in_channels*2, in_channels, kernel_size=1),
            nn.Sigmoid()
        )
        
    def forward(self, current, previous):
        # 
        combined = torch.cat([current, previous], dim=1)
        
        # 
        memory = self.cell(combined)
        update = self.update_gate(combined)
        

        change_sensitivity = self.change_gate(combined)
      
        output = update * current + (1 - update) * memory
        
        output = change_sensitivity * output + (1 - change_sensitivity) * current
        
        output = self.output_transform(output)
        
        return output


class REFM(nn.Module):
    
    def __init__(self, in_channels=32):
        super(REFM, self).__init__()
        
    
        self.feature_enhance = nn.Sequential(
            nn.Conv2d(in_channels*2, in_channels*2, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_channels*2),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels*2, in_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_channels)
        )
       
        self.reg_quality = nn.Sequential(
            nn.Conv2d(in_channels*2, in_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels, 1, kernel_size=1),
            nn.Sigmoid()
        )
  
        self.object_attention = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=1),
            nn.BatchNorm2d(in_channels),
            nn.Sigmoid()
        )
 
        self.edge_enhance = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True)
        )
        
    def forward(self, f1, f2, m1, m2):

        f1_combined = torch.cat([f1, m1], dim=1)
        f2_combined = torch.cat([f2, m2], dim=1)
        

        f1_enhanced = self.feature_enhance(f1_combined)
        f2_enhanced = self.feature_enhance(f2_combined)
        

        f1_edge = self.edge_enhance(f1_enhanced)
        f2_edge = self.edge_enhance(f2_enhanced)
        

        reg_inputs = torch.cat([f1_enhanced, f2_enhanced], dim=1)
        reg_quality = self.reg_quality(reg_inputs)
        

        obj_attn1 = self.object_attention(f1_enhanced)
        obj_attn2 = self.object_attention(f2_enhanced)
        

        f1_fg = (f1_enhanced + f1_edge) * obj_attn1
        f2_fg = (f2_enhanced + f2_edge) * obj_attn2
        

        diff = torch.abs(f1_fg - f2_fg) * reg_quality
        
        return f1_fg, f2_fg, diff


class PIGOM(nn.Module):

    def __init__(self, num_iterations=5):
        super(PIGOM, self).__init__()
        self.num_iterations = num_iterations
        
        
        self.param_net = nn.Sequential(
            nn.Conv2d(3, 16, kernel_size=3, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True),
            nn.Conv2d(16, 16, kernel_size=3, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True),
            nn.Conv2d(16, 3, kernel_size=1),
            nn.Sigmoid()
        )
        
      
        self.prior_encoder = nn.Sequential(
            nn.Conv2d(32*2, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 16, kernel_size=3, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True),
            nn.Conv2d(16, 1, kernel_size=1),
            nn.Sigmoid()
        )
        
     
        self.classifier = nn.Sequential(
            nn.Conv2d(1, 8, kernel_size=3, padding=1),
            nn.BatchNorm2d(8),
            nn.ReLU(inplace=True),
            nn.Conv2d(8, 2, kernel_size=1)
        )
        
    
        self._initialize_weights()
        
    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
        
    def forward(self, change_pre, f1, f2):
        # Extract initial change prediction (probability map)
        m = torch.sigmoid(change_pre[:, 0:1])
        
        # Generate coefficients for PDE
        params_input = torch.cat([m, f1.mean(dim=1, keepdim=True), f2.mean(dim=1, keepdim=True)], dim=1)
        params = self.param_net(params_input)
        alpha, beta, gamma = params[:, 0:1], params[:, 1:2], params[:, 2:3]
        
 
        alpha = alpha * 1.5  #
        beta = beta * 0.8    # 
        gamma = gamma * 0.5  # 
        
        # Generate physical prior 
        physical_prior = self.prior_encoder(torch.cat([f1, f2], dim=1))
        
        # Iterative PDE solving
        for _ in range(self.num_iterations):
            # Signal enhancement term
            signal = F.relu(change_pre[:, 0:1])
            enhance_term = alpha * signal * (1 - m)
            
            # Smoothing term (Laplacian + gradient magnitude)
            laplacian = self._compute_laplacian(m)
            grad_mag = self._compute_gradient_magnitude(m)
            smooth_term = beta * (laplacian + 0.1 * grad_mag)
            
            # Physical prior term
            prior_term = gamma * physical_prior * m
            
            # Update state with adjusted step size
            dm = enhance_term - smooth_term - prior_term
            m = torch.clamp(m + 0.2 * dm, 0, 1)  # 增大步长
        

        output = self.classifier(m)
        
        return output
    
    def _compute_laplacian(self, x):
        """Compute Laplacian operator: ∇²x"""
        kernel = torch.tensor([[0, 1, 0], [1, -4, 1], [0, 1, 0]], dtype=torch.float32, device=x.device)
        kernel = kernel.view(1, 1, 3, 3)
        return F.conv2d(x, kernel, padding=1)
    
    def _compute_gradient_magnitude(self, x):
        """Compute gradient magnitude: |∇x|"""
        kernel_x = torch.tensor([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=torch.float32, device=x.device)
        kernel_y = torch.tensor([[1, 2, 1], [0, 0, 0], [-1, -2, -1]], dtype=torch.float32, device=x.device)
        
        kernel_x = kernel_x.view(1, 1, 3, 3)
        kernel_y = kernel_y.view(1, 1, 3, 3)
        
        grad_x = F.conv2d(x, kernel_x, padding=1)
        grad_y = F.conv2d(x, kernel_y, padding=1)
        
        return torch.sqrt(grad_x**2 + grad_y**2 + 1e-6)


###############################################################################
# Main FGCD-R Network
###############################################################################

class FGCD_R(nn.Module):
    """
    Fine-Grained Change Detection for Unregistered Remote Sensing Images - 增强版
    """
    def __init__(self, with_pos='learned', input_nc=3, output_nc=2, backbone='resnet18', output_sigmoid=False, resnet_stages_num=4,
                 token_len=4, token_trans=True,
                 enc_depth=1, dec_depth=1,
                 dim_head=64, decoder_dim_head=64,
                 tokenizer=True, if_upsample_2x=True,
                 pool_mode='max', pool_size=2,
                 decoder_softmax=True, with_decoder_pos=None,
                 with_decoder=True):
        super(FGCD_R, self).__init__()
        self.backbone = backbone
        self.output_sigmoid = output_sigmoid
        self.sigmoid = nn.Sigmoid()
        
        # Feature extractor for initial feature extraction
        self.feature_extractor = FeatureExtractor(input_nc, backbone)
        
        #
        self.image_transform = ImageTransform(ET_kernel_size=101, ET_kernel_sigma=16, AT_translate=0.02, convert_to_gray=True)
        
        #
        self.sacam = SACAM(in_channels=32)
        self.dtmm = DTMM(in_channels=32)
        self.refm = REFM(in_channels=32)
        self.pigom = PIGOM(num_iterations=5)
        
        # 
        self.decoder = nn.Sequential(
            nn.Conv2d(32*3, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, output_nc, kernel_size=1)
        )
        
        # 
        self.upsamplex2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        self.upsamplex4 = nn.Upsample(scale_factor=4, mode='bilinear', align_corners=True)
       
        # 
        self.token_len = token_len
        self.conv_a = nn.Conv2d(32, self.token_len, kernel_size=1, padding=0, bias=False)
        self.tokenizer = tokenizer
        if not self.tokenizer:
            self.pooling_size = pool_size
            self.pool_mode = pool_mode
            self.token_len = self.pooling_size * self.pooling_size

        self.token_trans = token_trans
        self.with_decoder = with_decoder
        dim = 32
        mlp_dim = 2*dim

        self.with_pos = with_pos
        if with_pos == 'learned':
            self.pos_embedding = nn.Parameter(torch.randn(1, self.token_len*2, 32))
        decoder_pos_size = 256//4
        self.with_decoder_pos = with_decoder_pos
        if self.with_decoder_pos == 'learned':
            self.pos_embedding_decoder = nn.Parameter(torch.randn(1, 32, decoder_pos_size, decoder_pos_size))
        self.enc_depth = enc_depth
        self.dec_depth = dec_depth
        self.dim_head = dim_head
        self.decoder_dim_head = decoder_dim_head
        self.transformer = Transformer(dim=dim, depth=self.enc_depth, heads=8,
                                       dim_head=self.dim_head,
                                       mlp_dim=mlp_dim, dropout=0)
        self.transformer_decoder = TransformerDecoder(dim=dim, depth=self.dec_depth,
                            heads=8, dim_head=self.decoder_dim_head, mlp_dim=mlp_dim, dropout=0,
                                                      softmax=decoder_softmax)
        
        # 
        self.large_w_size = #choose,your image size
        self.small_w_size = #choose, your image size
        
        # 
        self.aux_head = nn.Sequential(
            nn.Conv2d(32, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, output_nc, kernel_size=1)
        )
        
        #
        self._initialize_weights()
        
    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

    def _forward_semantic_tokens(self, x):
        b, c, h, w = x.shape
        spatial_attention = self.conv_a(x)
        spatial_attention = spatial_attention.view([b, self.token_len, -1]).contiguous()
        spatial_attention = torch.softmax(spatial_attention, dim=-1)
        x = x.view([b, c, -1]).contiguous()
        tokens = torch.einsum('bln,bcn->blc', spatial_attention, x)

        return tokens

    def _forward_reshape_tokens(self, x):
        if self.pool_mode == 'max':
            x = F.adaptive_max_pool2d(x, [self.pooling_size, self.pooling_size])
        elif self.pool_mode == 'ave':
            x = F.adaptive_avg_pool2d(x, [self.pooling_size, self.pooling_size])
        else:
            x = x
        tokens = rearrange(x, 'b c h w -> b (h w) c')
        return tokens

    def _congnitive_attention(self, x):
        if self.with_pos:
            x += self.pos_embedding
        x = self.transformer(x)
        return x

    def _forward_transformer_decoder(self, x, m):
        b, c, h, w = x.shape
        if self.with_decoder_pos == 'fix':
            x = x + self.pos_embedding_decoder
        elif self.with_decoder_pos == 'learned':
            x = x + self.pos_embedding_decoder
        
        x = rearrange(x, 'b c h w -> b (h w) c')
        x = self.transformer_decoder(x, m)
        x = rearrange(x, 'b (h w) c -> b c h w', h=h)
        return x  
    
    def forward(self, x1, x2, is_training=True):
        # If is_training parameter is not provided, use the model's current state
        if is_training is None:
            is_training = self.training
        
  
                
            # 
            x1_d, x2_d, _, index_r, _ = self.image_transform(x1, x2)  # 
        
        # 
        f1_init = self.feature_extractor(x1_d)
        f2_init = self.feature_extractor(x2_d)
        
        # SACAM module - handle global misalignment and radiometric inconsistency
        f1_sacam, f2_sacam = self.sacam(f1_init, f2_init)
        
        # Calculate difference features from SACAM
        d_sacam = torch.abs(f1_sacam - f2_sacam)
        
        # DTMM module - handle local non-rigid deformation and distinguish real changes
        m1, m2, d_dtmm = self.dtmm(f1_sacam, f2_sacam)
        
        # REFM module - enhance fine-grained object features
        f1_refm, f2_refm, d_refm = self.refm(f1_sacam, f2_sacam, m1, m2)
        
        # Combine difference features from all modules
        combined_diff = torch.cat([d_sacam, d_dtmm, d_refm], dim=1)
        
        # Generate initial change prediction
        change_pre = self.decoder(combined_diff)
        
        # 
        aux_out = self.aux_head(d_dtmm)
        
        # PIGOM module - optimize fine-grained change detection with physical constraints
        change_final = self.pigom(change_pre, f1_refm, f2_refm)
        
        # 
        _, _, h, w = change_final.shape
        target_size = 256
        
        # 
        scale_factor = target_size // h
        
        
        if h != target_size:
            change_final = F.interpolate(
                change_final, 
                size=(target_size, target_size), 
                mode='bilinear', 
                align_corners=True
            )
            
            aux_out = F.interpolate(
                aux_out, 
                size=(target_size, target_size), 
                mode='bilinear', 
                align_corners=True
            )
            
            change_pre = F.interpolate(
                change_pre, 
                size=(target_size, target_size), 
                mode='bilinear', 
                align_corners=True
            )
        
        # Apply sigmoid activation if required
        if self.output_sigmoid:
            change_final = self.sigmoid(change_final)
            aux_out = self.sigmoid(aux_out)
            change_pre = self.sigmoid(change_pre)
        
        # If in training mode, return intermediate results for loss calculation
        if is_training:
            return change_final, {
                'f1_sacam': f1_sacam, 'f2_sacam': f2_sacam,
                'm1': m1, 'm2': m2,
                'f1_refm': f1_refm, 'f2_refm': f2_refm,
                'change_pre': change_pre,
                'aux_out': aux_out,
                'x1_d': x1_d, 'x2_d': x2_d,
                'index_r': index_r
            }
        else:
            return change_final
        
    