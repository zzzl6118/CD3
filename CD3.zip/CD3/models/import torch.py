import torch
import torch.nn as nn
from torch.nn import init
import torch.nn.functional as F
from torch.optim import lr_scheduler
import numpy as np
from torchvision.transforms import ToTensor
import functools
from einops import rearrange
import cv2




import torchvision.models as models2

class Neural_scroll_zl(nn.Module):
    def __init__(self, feature_dims=3, num_classes=3):
        super(Neural_scroll_zl, self).__init__()

        
        self.input_adjust1 = nn.Conv2d(8, feature_dims[0], kernel_size=1, stride=1, padding=0)
        self.input_adjust2 = nn.Conv2d(8, feature_dims[1], kernel_size=1, stride=1, padding=0)
        self.input_adjust3 = nn.Conv2d(8, feature_dims[2], kernel_size=1, stride=1, padding=0)

        # 
        import ssl
        ssl._create_default_https_context = ssl._create_unverified_context

        # 
        self.backbone1 = models2.detection.fasterrcnn_resnet50_fpn(pretrained=False, num_classes=num_classes)
        self.backbone1.backbone.conv1 = nn.Identity()  # 

        # 
        self.backbone2 = models2.detection.fasterrcnn_resnet50_fpn(pretrained=False, num_classes=num_classes)
        self.backbone2.backbone.conv1 = nn.Conv2d(feature_dims[1], 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.backbone2.backbone.bn1 = nn.Identity()  # 

        # 
        self.fusion_layer = nn.Conv2d(feature_dims[0] + feature_dims[1] + feature_dims[2], feature_dims[0], kernel_size=1, stride=1, padding=0)

        # 
        self.rpn = self.backbone1.rpn
        self.classifier = self.backbone1.roi_heads.box_predictor

    def forward(self, input):
        feature1, feature2, feature3 = input
        # 
        output1 = self.backbone1(feature1)

        # 
        output2 = self.backbone2(feature2)

        #
        output = torch.cat([output1['tensors'], output2['tensors'], feature3], dim=1)

        # 
        output = self.fusion_layer(output)

        # 
        rpn_output = self.rpn(output)
        classifier_output = self.classifier(output, rpn_output)

        # 
        boxes = classifier_output[0]['boxes'].detach().cpu().numpy()
        labels = classifier_output[0]['labels'].detach().cpu().numpy()

        return boxes, labels

model = Neural_scroll_zl()


feature1 = torch.randn(1, 8, 32, 64, 64)
feature2 = torch.randn(1, 8, 32, 64, 64)
feature3 = torch.randn(1, 8, 32, 64, 64)
inputs = (feature1, feature2, feature3)


boxes, labels = model(inputs)

print("Predicted bounding boxes:", boxes)
print("Predicted labels:", labels)
        

